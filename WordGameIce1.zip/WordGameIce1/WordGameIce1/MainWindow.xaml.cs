﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace WordGameIce1
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        private List<string> words = new List<string> { "europe", "asia", "africa", "south", "north","antartica" };
        private string currentWord;
        private int score = 0;

        public MainWindow()
        {
            InitializeComponent();
        }

        private void PlayButton_Click(object sender, RoutedEventArgs e)
        {
            int randomIndex = new Random().Next(words.Count);
            currentWord = words[randomIndex];
            wordLabel.Content = ScrambleWord(currentWord);
        }

        private void CheckButton_Click(object sender, RoutedEventArgs e)
        {
            string userAnswer = answerTextBox.Text.ToLower();
            if (userAnswer == currentWord)
            {
                MessageBox.Show("CORRECT", "Result", MessageBoxButton.OK, MessageBoxImage.Information);
                score++;
            }
            else
            {
                MessageBox.Show("INCORRECT", "Result", MessageBoxButton.OK, MessageBoxImage.Error);
                score = Math.Max(0, score - 1);
            }
            UpdateScoreLabel();
        }

        private void UpdateScoreLabel()
        {
            scoreLabel.Content = "Score: " + score;
        }

        private string ScrambleWord(string word)
        {
            char[] chars = word.ToCharArray();
            Random rand = new Random();
            for (int i = chars.Length - 1; i > 0; i--)
            {
                int j = rand.Next(i + 1);
                char temp = chars[i];
                chars[i] = chars[j];
                chars[j] = temp;
            }
            return new string(chars);
        }


    }
}

